/* eslint-disable no-undef */
module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ]
}
