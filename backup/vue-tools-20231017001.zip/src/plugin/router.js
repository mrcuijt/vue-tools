import Vue from 'vue'
import Router from 'vue-router'
import TabA from '@/components/el-tabs/TabA'
import TabB from '@/components/el-tabs/TabB'
import BilibiliDanmuk from '@/components/el-tabs/bilibili/BilibiliDanmuk'
import PrettierIndex from '@/components/prettier/PrettierIndex'
import PrettierCode from '@/components/prettier/PrettierCode'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/tabA',
      name: 'TabA',
      component: TabA
    },
    {
      path: '/tabB',
      name: 'TabB',
      component: TabB
    },
    {
      path: '/danmuk',
      name: 'BilibiliDanmuk',
      component: BilibiliDanmuk
    },
    {
      path: '/code',
      name: 'PrettierIndex',
      component: PrettierIndex
    },
    {
      path: '/codeformat',
      name: 'PrettierCode',
      component: PrettierCode
    }
  ]
})
