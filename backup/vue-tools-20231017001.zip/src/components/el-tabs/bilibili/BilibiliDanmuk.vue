<template>
  <div>
    {{ msg }}
  </div>
</template>
<script>

export default {
  name: 'BilibiliDanmuk',
  components: {
  },
  data () {
    return {
      msg: 'Bilibili Danmuk',
    }
  },
  computed: {
  },
  methods: {
  },
  mounted () {
  },
  unmounted () { },
}
</script>

<style></style>