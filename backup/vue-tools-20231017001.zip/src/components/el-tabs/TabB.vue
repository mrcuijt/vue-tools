<template>
  <div class="hello">{{ msg }}</div>
</template>

<script>

export default {
  name: 'TabB',
  components: {

  },
  data () {
    return {
      msg: 'Component B'
    }
  },
  methods: {

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
